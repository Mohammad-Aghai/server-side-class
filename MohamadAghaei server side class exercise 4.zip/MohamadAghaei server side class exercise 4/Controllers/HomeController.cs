using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mohamad_Aghaei.Models;

namespace Mohamad_Aghaei.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult ContactUs()
    {
return View();
    }
     public IActionResult Store(Products product02)
        {
            List<Products> products = new List<Products>();


            Products product1 = new Products();
            product1.Id = 1;
            product1.NamKala = "  گوشی honor 9x  ";
            product1.MoshakhasatKala = " 4 GB ram snapdragone 630";
            product1.Tozihat = "موجود در 3 رنگ مشکی نقره ای و سفید ";
            product1.DasteBandi = "گوشی موبایل ";
            product1.Qeymat = 9000000;
            product1.Mojodi = true;
            products.Add(product1);


            Products product2 = new Products();
           product2.Id = 2;
            product2.NamKala = "گوشی سامسوتگ galaxy s8 pro   ";
            product2.MoshakhasatKala = "جنس بدنه شیشه و پلاستیک ";
            product2.Tozihat ="موجود در 3 رنگ مشکی نقره ای و سفید ";
            product2.DasteBandi =  "گوشی موبایل ";
            product2.Qeymat = 4440000;
            product2.Mojodi = true;
            products.Add(product2);


            Products product3 = new Products();
            product3.Id = 3;
            product3.NamKala = " لپ تاپ ایسوس G66";
            product3.MoshakhasatKala = "جنس بدنه پلاستیک";
            product3.Tozihat ="موجود در 3 رنگ مشکی نقره ای و سفید ";
            product3.DasteBandi = "لپ تاب";
            product3.Qeymat = 189750000;
            product3.Mojodi = true;
            products.Add(product3);


            Products product4 = new Products();
           product4.Id = 4;
            product4.NamKala = "ساعت هوشمند اپل";
            product4.MoshakhasatKala = "جنس بدنه نقره";
            product4.Tozihat ="موجود در 3 رنگ مشکی نقره ای و سفید ";
            product4.DasteBandi = "ساعت هوشمند ";
            product4.Qeymat = 365480000;
            product4.Mojodi = true;
            products.Add(product4);
            var BOBBY = products.Where(x=>x.Mojodi).ToList();
            var sum= products.Sum(x=>x.Qeymat);
            ViewBag.Sum = sum;
            return View(BOBBY);
        }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
