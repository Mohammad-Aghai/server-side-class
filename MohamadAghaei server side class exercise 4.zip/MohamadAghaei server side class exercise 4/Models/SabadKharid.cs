﻿using System.ComponentModel.DataAnnotations;
namespace Mohamad_Aghaei.Models
{
    public class Basket
    {
        [Key]
        public int id { get; set; }
        [Required]
        [StringLength(50)]
        public string nam { get; set; }
        [StringLength(50)]
        public string DasteBandi { get; set; }
        public int Qeymat { get; set; }
    }
}