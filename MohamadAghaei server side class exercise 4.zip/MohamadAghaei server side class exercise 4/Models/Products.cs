using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Mohamad_Aghaei.Models
{

 public class Products
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(100)]
        public string NamKala { get; set; }
        [StringLength(50)]
        public string MoshakhasatKala { get; set; }
        [StringLength(200)]
        public string Tozihat { get; set; }
        [Required]
        [StringLength(20)]
        public string DasteBandi { get; set; }
        public Nullable<int> Qeymat { get; set; }
        [Required]
        public bool Mojodi{ get; set; }

    }

}