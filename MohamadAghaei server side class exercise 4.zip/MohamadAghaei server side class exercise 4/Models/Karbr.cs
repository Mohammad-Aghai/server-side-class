﻿using System.ComponentModel.DataAnnotations;
namespace Mohamad_Aghaei.Models

{
    public class Users
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Nam { get; set; }
        [Required]
        [StringLength(50)]
        public string famili { get; set; }
        [Required]
        [EmailAddress]
        [StringLength(50)]
        public string Email { get; set; }
        [StringLength(50)]
        public string shomare { get; set; }
        [Required]
        [StringLength(50)]
        public string ramz { get; set; }

    }
}