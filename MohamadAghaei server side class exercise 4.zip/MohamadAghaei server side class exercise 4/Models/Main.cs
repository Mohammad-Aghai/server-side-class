﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace Mohamad_Aghaei.Models
{
    public class Context : DbContext
    {
        public Main(DbContextOptions<Main> options) : base(options)
        {
        }
        public DbSet<karbr> karbr { get; set; }
        public DbSet<Products> Productss { get; set; }
        public DbSet<SabadKharid> SabadKharid { get; set; }
    }
}