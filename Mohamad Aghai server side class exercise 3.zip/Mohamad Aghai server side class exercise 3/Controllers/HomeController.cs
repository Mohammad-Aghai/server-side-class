﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mohamad_Aghai_server_side_class_exercise_3.Models;

namespace Mohamad_Aghai_server_side_class_exercise_3.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index(productList myProducts)
    { 
         List<productList> products = new List<productList>();
      
       productList product_1  = new productList();
       product_1.Category =  "smart phones" ; 
       product_1.Id  =  1 ; 
       product_1.ProductName = "samsung galaxy S21";
       product_1.ProductCount =  20;
       product_1.Price =  1200 ; 
       product_1.stock  =  true ; 
       products.Add(product_1);
        productList product_2 = new productList();
        product_2.Category =  "laptop" ; 
        product_2.Id  =  2 ; 
        product_2.ProductName = "lenovo G500";
        product_2.ProductCount =  30;
        product_2.Price =  1900 ; 
        product_2.stock  =  true ; 
       products.Add(product_2);
       
         var stockFilter = products.Where(x=>x.stock == true ).ToList();
           int sumPrice  = 0 ;
           foreach(var items in stockFilter){
            sumPrice += items.Price;
           }
           ViewBag.Sum = sumPrice;
            return View(stockFilter);
    }
    public IActionResult AboutUs()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
