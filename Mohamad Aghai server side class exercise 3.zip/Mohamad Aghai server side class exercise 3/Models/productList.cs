using System.ComponentModel.DataAnnotations;

namespace Mohamad_Aghai_server_side_class_exercise_3.Models
{
    public class productList
    {
        [StringLength(100)]
        public string Category { get; set; }
          [Key]
          [Required]
        public int Id { get; set; }
        [StringLength(100)]
        public string ProductName { get; set; }
           [MaxLength()]
        public int  ProductCount { get; set; }
        [MaxLength()]
        public int  Price { get; set; }
        public bool stock { get; set; }
    }
}